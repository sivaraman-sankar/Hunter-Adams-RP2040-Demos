# Sensor demonstrations

#### MPU6050 Demo
- Demonstrates a simple library for interfacing the RP2040 with the MPU6050 IMU
- Communicates with the sensor over SPI, and plots the raw accelerometer/gyro measurements on the VGA display