/**
 * V. Hunter Adams (vha3@cornell.edu)
 * PWM demo code with serial input
 *
 * This demonstration sets a PWM duty cycle to a
 * user-specified value.
 *
 * HARDWARE CONNECTIONS
 *   - GPIO 4 ---> PWM output
 * 
 * =================================================================
 * Notes from class recording (ignore)
 * 
 * Two processes -
 * 1. Controller (high priority)
 * 2. User interface (low priority)
 * 
 * =================================================================
 * Closing the loop 
 * 
 * 1. Read from the IMU sensor (I2C) 
 *  - Gives accelartion 
 *  - Angular rate 
 *  - Use that for estimating the arm angle 
 * 
 * Complimentary filter 
 * 
 * |     / 
 * |    / 
 * |   / 
 * |  /
 * | / 
 * |/
 * ___
 * 
 * theta = arctan(a_x/a_y)
 * 
 * Why gyro ? 
 * Noise -- accelerometer is noisy; when motor is running causes vibrations and other pertrubations. Doesn't enable closed loop control. 
 * 
 * Output = true noise + noise (Zero mean gaussian white noise )
 * 
 * Gyro -- 
 * Angular rate, how quickly its rotating. (w) degrees/second 
 * They develop a bias, even if low noise - nice clean output, but they will drift 
 * 
 * Complimentary filter = retain good properties of both sensors and eliminate the others
 * 
 * - This is time sensitive, so move it into ISR 
 * 
 * - Algo 
 * 
 * - Gather ax, ay, az 
 * - Use 2 of the three, weighted accel angle estimate ( theta = ax/ay*180/pi) -- depends how you mount the IMU sensor
 * ay, az --> point the imu facing down slide (5)
 * - accel weight
 * - Low passing
 * 
 * - Gyro 
 * - Take gyro reading 
 * - Multiply by dt, 1khz = 0.001 second 
 * - Gyro weight  ( usually higher than accel weight )
 * - High passing
 * 
 * Sum both to get complimentary angle which will be given to PID controller  
 * 
 * ====================== 
 * PID 
 *  P - proportional to current and desired state (current)
 *  I - current and history of error (past)
 *  D - rate of change and scales it (future)
 * 
 * 
 * Only P --
 *  - Oscillations (high Kp) 
 *  - Steady state error will always occur
 *  - kp.e  ==> gain of the system 
 * 
 * I - 
 * 
 * Ki. sigma(e. dt) 
 * 
 * Mitigates some issues -- 
 * - allows for controller to notice that steady state error and solve it
 * - oscillations still occur
 * Notes - cap the integral term to some maximal value 
 * 
 * D - 
 * kd. de/dt  
 * 
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "pico/stdlib.h"
#include "pico/multicore.h"

#include "hardware/pwm.h"
#include "hardware/irq.h"

#include "pt_cornell_rp2040_v1_3.h"

// PWM wrap value and clock divide value
// For a CPU rate of 125 MHz, this gives
// a PWM frequency of 1 kHz.
// 125Mhz/25/5000 = 1KHz 
#define WRAPVAL 5000
#define CLKDIV 25.0f

// GPIO we're using for PWM
// All 30 GPIO pins in RP2040 can be used for PWM. Each pin has a associated slice for pin 4 - Channel 2A
#define PWM_OUT 4

// Variable to hold PWM slice number
uint slice_num;

// PWM duty cycle
volatile int control;
volatile int old_control;
volatile int inverted_control;

// PWM interrupt service routine
void on_pwm_wrap()
{
    // Clear the interrupt flag that brought us here
    pwm_clear_irq(pwm_gpio_to_slice_num(PWM_OUT));
    // Update duty cycle
    if (control != old_control)
    {
        old_control = control;
        inverted_control = WRAPVAL - control;  // inverts the control value 
        pwm_set_chan_level(slice_num, PWM_CHAN_A, inverted_control);
    }
}

// User input thread
static PT_THREAD(protothread_serial(struct pt *pt))
{
    PT_BEGIN(pt);
    static int test_in;
    while (1)
    {
        sprintf(pt_serial_out_buffer, "input a duty cycle (0-5000):: ");
        serial_write;
        // spawn a thread to do the non-blocking serial read
        serial_read;
        // convert input string to number
        sscanf(pt_serial_in_buffer, "%d", &test_in);
        if (test_in > 5000)
            continue;
        else if (test_in < 0)
            continue;
        else
            control = test_in;
    }
    PT_END(pt);
}

int main()
{
    sprintf(pt_serial_out_buffer, "Testing the PWM example ...\n");
    // Initialize stdio
    stdio_init_all();

    ////////////////////////////////////////////////////////////////////////
    ///////////////////////// PWM CONFIGURATION ////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    // Tell GPIO PWM_OUT that it is allocated to the PWM
    gpio_set_function(PWM_OUT, GPIO_FUNC_PWM);

    // Find out which PWM slice is connected to GPIO PWM_OUT (it's slice 2)
    slice_num = pwm_gpio_to_slice_num(PWM_OUT);

    // Mask our slice's IRQ output into the PWM block's single interrupt line,
    // and register our interrupt handler
    pwm_clear_irq(slice_num);
    pwm_set_irq_enabled(slice_num, true); // enable the slice associated with our gpio channel
    irq_set_exclusive_handler(PWM_IRQ_WRAP, on_pwm_wrap); // every time it fires, call the on_pwn_wrap funciton 
    irq_set_enabled(PWM_IRQ_WRAP, true); // enable the irq

    // This section configures the period of the PWM signals
    pwm_set_wrap(slice_num, WRAPVAL);
    pwm_set_clkdiv(slice_num, CLKDIV);

    // This sets duty cycle
    pwm_set_chan_level(slice_num, PWM_CHAN_A, 3125); // 3125 is going to be modifiable by the user. 

    // Start the channel
    pwm_set_mask_enabled((1u << slice_num));

    ////////////////////////////////////////////////////////////////////////
    ///////////////////////////// ROCK AND ROLL ////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    pt_add_thread(protothread_serial);
    pt_schedule_start;
}
